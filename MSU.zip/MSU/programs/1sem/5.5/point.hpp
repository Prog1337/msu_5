#pragma once

struct Point
{
public:
	explicit Point(float x = 0., float y = 0.) : _x(x), _y(y){};

	float X() const { return _x; }
	float Y() const { return _y; }

private:
	float _x = 0., _y = 0.;
};
