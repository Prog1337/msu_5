#pragma once

#include "point.hpp"

struct Polygon
{
public:
	explicit Polygon(int verticesCount) : _verticesCount(verticesCount), _vertices(new Point[verticesCount]) {}

	int GetVerticesCount() const { return _verticesCount; }

	void SetVertex(int index, float x = 0., float y = 0.) { _vertices[index] = Point(x, y); }

	Point &operator[](int index) const { return _vertices[index]; }

	~Polygon() { delete[] _vertices; }

private:
	Point *_vertices = nullptr;
	int _verticesCount = -1;
};
