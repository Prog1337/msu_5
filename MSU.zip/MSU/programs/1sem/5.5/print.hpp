#pragma once

#include <fstream>
#include "polygon.hpp"

void Print( std::ofstream &fout , Polygon *const polygon)
{
    int verticesCount = polygon->GetVerticesCount();
    fout << "Vertices count: " << verticesCount << std::endl;
    for (int i = 0; i < verticesCount; i++)
    {
        fout << "Vertex(" << i << ") = ";
        fout << "(" << (*polygon)[i].X() << ", " << (*polygon)[i].Y() << ")";
        if (i != verticesCount - 1)
            fout << ", " << std::endl;
        else
            fout << std::endl;
    }
}