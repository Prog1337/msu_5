#pragma once

#include "point.hpp"
#include "vector.hpp"
#include "polygonInstantiation.hpp"
#include "print.hpp"
#include "distance.hpp"