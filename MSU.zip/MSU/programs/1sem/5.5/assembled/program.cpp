#include <iostream>
#include <fstream>
#include <cmath>
#include <limits>

const float MAX = std::numeric_limits<float>::max();

struct Point
{
public:
    explicit Point(float x = 0., float y = 0.) : _x(x), _y(y){};

    float X() const { return _x; }
    float Y() const { return _y; }

private:
    float _x = 0., _y = 0.;
};

struct Vector : Point
{
public:
    explicit Vector(float x0, float x1, float y0, float y1) : Point(x1 - x0, y1 - y0) {}
};

struct Polygon
{
public:
    explicit Polygon(int verticesCount) 
    {
		_verticesCount = verticesCount;
		_vertices = new Point[verticesCount];
	}

    int GetVerticesCount() const { return _verticesCount; }

    void SetVertex(int index, float x = 0., float y = 0.) { _vertices[index] = Point(x, y); }

    Point &operator[](int index) const { return _vertices[index]; }

    ~Polygon() { delete[] _vertices; }

private:
    Point *_vertices;
    int _verticesCount;
};

Polygon *InstantiatePolygon(std::ifstream &fin, int &verticesCount)
{
    if (!fin || !(fin >> verticesCount) || verticesCount <= 2)
        return nullptr;

    Polygon *polygon = new Polygon(verticesCount);

    for (int i = 0; i < verticesCount; i++)
    {
        float x, y;
        fin >> x >> y;
        polygon->SetVertex(i, x, y);
    }

    return polygon;
}

bool IsInside(const Point &point, const Polygon &polygon, const int verticesCount)
{
    bool result = false;
    for (int i = 0, j = verticesCount - 1; i < verticesCount; j = i++)
    {
        if ((((polygon[i].Y() <= point.Y()) && (point.Y() < polygon[j].Y())) ||
             ((polygon[j].Y() <= point.Y()) && (point.Y() < polygon[i].Y()))) &&
            (point.X() < (polygon[j].X() - polygon[i].X()) * (point.Y() - polygon[i].Y()) / (polygon[j].Y() - polygon[i].Y()) + polygon[i].X()))
            result = !result;
    }
    return result;
}

float Distance(const Point &E, const Point &A, const Point &B)
{
    Vector AB = Vector(B.X(), A.X(), B.Y(), A.Y());
    Vector BE = Vector(E.X(), B.X(), E.Y(), B.Y());
    Vector AE = Vector(E.X(), A.X(), E.Y(), A.Y());

    float AB_BE = (AB.X() * BE.X() + AB.Y() * BE.Y());
    float AB_AE = (AB.X() * AE.X() + AB.Y() * AE.Y());
    float minDist = 0.;

    if (AB_BE > 0)
    {
        float x = E.X() - B.X();
        float y = E.Y() - B.Y();
        minDist = sqrt(x * x + y * y);
    }

    else if (AB_AE < 0)
    {
        float x = E.X() - A.X();
        float y = E.Y() - A.Y();
        minDist = sqrt(x * x + y * y);
    }

    else
    {
        float x1 = AB.X();
        float y1 = AB.Y();
        float x2 = AE.X();
        float y2 = AE.Y();
        float mod = sqrt(x1 * x1 + y1 * y1);
        minDist = fabs(x1 * y2 - y1 * x2) / mod;
    }

    return minDist;
}

float Distance(const Polygon &polygon1, const Polygon &polygon2)
{
    float minDist = MAX, dist = 0.;
    int verticesCount1 = polygon1.GetVerticesCount();
    int verticesCount2 = polygon2.GetVerticesCount();

    for (int i = 0; i < verticesCount1; i++)
    {
        // std::cout << "Distance between (" << polygon1[i].X() << ", " << polygon1[i].Y() << ") and line" << std::endl;
        for (int j = 0; j < verticesCount2; j++)
        {
            dist = Distance(polygon1[i], polygon2[j % verticesCount2], polygon2[(j + 1) % verticesCount2]);
            // std::cout << "{(" << polygon2[j % verticesCount2].X() << ", " << polygon2[j % verticesCount2].Y() << "), (" << polygon2[(j + 1) % verticesCount2].X() << ", " << polygon2[(j + 1) % verticesCount2].Y() << ")}: " << dist << std::endl;
            if (dist < minDist)
                minDist = dist;
        }
    }

    for (int i = 0; i < verticesCount2; i++)
    {
        for (int j = 0; j < verticesCount1; j++)
        {
            dist = Distance(polygon2[i], polygon1[j % verticesCount1], polygon1[(j + 1) % verticesCount1]);
            if (dist < minDist)
                minDist = dist;
        }
    }

    return minDist;
}

void Distance()
{
    std::ifstream fin("input.txt");
    std::ofstream fout("output.txt");

    Polygon *polygon1, *polygon2;
    int verticesCount1, verticesCount2;

    polygon1 = InstantiatePolygon(fin, verticesCount1);
    polygon2 = InstantiatePolygon(fin, verticesCount2);

    if (polygon1 == nullptr || polygon2 == nullptr)
    {
    SimpleCase:
        fout << "0" << std::endl;
        fin.close();
        fout.close();
        return;
    }

    for (int i = 0; i < verticesCount1; i++)
    {
        if (IsInside((*polygon1)[i], *polygon2, verticesCount2))
            goto SimpleCase;
    }

    for (int i = 0; i < verticesCount2; i++)
    {
        if (IsInside((*polygon2)[i], *polygon1, verticesCount1))
            goto SimpleCase;
    }

    fout << Distance(*polygon1, *polygon2) << std::endl;

    fin.close();
    fout.close();
    return;
}

int main()
{
    Distance();
}
