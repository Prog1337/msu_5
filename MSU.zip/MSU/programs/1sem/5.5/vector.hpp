#pragma once

#include "point.hpp"

struct Vector : Point
{
public:
    explicit Vector(float x0, float x1, float y0, float y1) : Point(x1 - x0, y1 - y0) {}
};
