#pragma once

#include <fstream>
#include "polygon.hpp"

Polygon *InstantiatePolygon(std::ifstream &fin, int &verticesCount)
{
    if (!fin || !(fin >> verticesCount) || verticesCount <= 2)
        return nullptr;

    Polygon *polygon = new Polygon(verticesCount);

    for (int i = 0; i < verticesCount; i++)
    {
        float x, y;
        fin >> x >> y;
        polygon->SetVertex(i, x, y);
    }

    return polygon;
}
