#pragma once

#include <fstream>
#include <cmath>
#include "polygonInstantiation.hpp"
#include "vector.hpp"
#include "print.hpp"

void Distance();
float Distance(const Polygon &polygon1, const Polygon &polygon2);
float Distance(const Point &E, const Point &A, const Point &B);
bool IsInside(const Point &point, const Polygon &polygon, const int verticesCount);

void Distance()
{
    std::ifstream fin("input.txt");
    std::ofstream fout("output.txt");

    Polygon *polygon1, *polygon2;
    int verticesCount1, verticesCount2;

    polygon1 = InstantiatePolygon(fin, verticesCount1);
    polygon2 = InstantiatePolygon(fin, verticesCount2);

    if (polygon1 == nullptr || polygon2 == nullptr)
    {
    SimpleCase:
        fout << "0" << std::endl;
        fin.close();
        fout.close();
        return;
    }

    for (int i = 0; i < verticesCount1; i++)
    {
        if (IsInside((*polygon1)[i], *polygon2, verticesCount2))
            goto SimpleCase;
    }

    for (int i = 0; i < verticesCount2; i++)
    {
        if (IsInside((*polygon2)[i], *polygon1, verticesCount1))
            goto SimpleCase;
    }

    fout << Distance(*polygon1, *polygon2) << std::endl;

    fin.close();
    fout.close();
    return;
}

float Distance(const Polygon &polygon1, const Polygon &polygon2)
{
    float minDist = MAXFLOAT, dist = 0.;
    int verticesCount1 = polygon1.GetVerticesCount();
    int verticesCount2 = polygon2.GetVerticesCount();

    for (int i = 0; i < verticesCount1; i++)
    {
        // std::cout << "Distance between (" << polygon1[i].X() << ", " << polygon1[i].Y() << ") and line" << std::endl;
        for (int j = 0; j < verticesCount2; j++)
        {
            dist = Distance(polygon1[i], polygon2[j % verticesCount2], polygon2[(j + 1) % verticesCount2]);
            // std::cout << "{(" << polygon2[j % verticesCount2].X() << ", " << polygon2[j % verticesCount2].Y() << "), (" << polygon2[(j + 1) % verticesCount2].X() << ", " << polygon2[(j + 1) % verticesCount2].Y() << ")}: " << dist << std::endl;
            if (dist < minDist)
                minDist = dist;
        }
    }

    return minDist;
}

float Distance(const Point &E, const Point &A, const Point &B)
{
    Vector AB = Vector(B.X(), A.X(), B.Y(), A.Y());
    Vector BE = Vector(E.X(), B.X(), E.Y(), B.Y());
    Vector AE = Vector(E.X(), A.X(), E.Y(), A.Y());

    float AB_BE = (AB.X() * BE.X() + AB.Y() * BE.Y());
    float AB_AE = (AB.X() * AE.X() + AB.Y() * AE.Y());
    float minDist = 0.;

    if (AB_BE > 0)
    {
        float x = E.X() - B.X();
        float y = E.Y() - B.Y();
        minDist = sqrt(x * x + y * y);
    }

    else if (AB_AE < 0)
    {
        float x = E.X() - A.X();
        float y = E.Y() - A.Y();
        minDist = sqrt(x * x + y * y);
    }

    else
    {
        float x1 = AB.X();
        float y1 = AB.Y();
        float x2 = AE.X();
        float y2 = AE.Y();
        float mod = sqrt(x1 * x1 + y1 * y1);
        minDist = fabs(x1 * y2 - y1 * x2) / mod;
    }

    return minDist;
}

bool IsInside(const Point &point, const Polygon &polygon, const int verticesCount)
{
    bool result = false;
    for (int i = 0, j = verticesCount - 1; i < verticesCount; j = i++)
    {
        if ((((polygon[i].Y() <= point.Y()) && (point.Y() < polygon[j].Y())) ||
             ((polygon[j].Y() <= point.Y()) && (point.Y() < polygon[i].Y()))) &&
            (point.X() < (polygon[j].X() - polygon[i].X()) * (point.Y() - polygon[i].Y()) / (polygon[j].Y() - polygon[i].Y()) + polygon[i].X()))
            result = !result;
    }
    return result;
}