#include <iostream>
#include <fstream>

typedef unsigned long long int ulli;

ulli Sum(ulli N)
{
    if (N / 10 > 0)
        return N % 10 + Sum(N / 10);
    else if (N % 10 > 0)
        return N;
    else
        return 0;
}

void Sum()
{
    std::ifstream fin("input.txt");
    std::ofstream fout("output.txt");

    ulli N;

    if (!fin || !(fin >> N) || N <= 0)
    {
        fout << "0" << std::endl;
        fin.close();
        fout.close();
        return;
    }

    fout << Sum(N) << std::endl;

    fin.close();
    fout.close();
}

int main()
{
    Sum();
}
