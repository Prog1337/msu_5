#include <iostream>
#include <fstream>

void InsertionSort()
{
    std::ifstream fin("input.txt");
    std::ofstream fout("output.txt");

    int length, *array;

    if(!fin || !(fin >> length) || length <= 0)
    {
        fout << "0"	<< std::endl;
        fin.close();
        fout.close();
        return;
    }

	fout << length << " ";
	
    array = new int[length];
    for(int i = 0; i < length; i++)
        fin >> array[i];

    for(int i = 1; i < length; i++)
    {
        int cur = array[i], j = i - 1;
        while(j >= 0 && cur < array[j])
        {
            array[j + 1] = array[j];
            j--;
        }
        array[j + 1] = cur;
    }

    for(int i = 0; i < length; i++)
		fout << array[i] << " ";
		
	delete[] array;
	fin.close();
	fout.close();
}

int main()
{
    InsertionSort();
}


