#include <iostream>
#include <cmath>
#include <fstream>

const float EPSILON = 1e-7;

void Segments()
{
	std::ifstream fin("input.txt");
	std::ofstream fout("output.txt");
	float x, prev, sum = 0., *array;
	int length, count = -1, right = 0;

	if(!(fin >> x))
	{
		fout << 0 << " ";
	BadFileCase:
		fin.close();
		fout.close();
		return;
	}
	
	fin >> length;
	fout << length << " ";

	fin >> prev;
	if (length == 1)
	{
		if (fabs(prev - x) < EPSILON)
			fout << 0 << " ";
		else
			fout << prev << " ";
		goto BadFileCase;
	}

	array = new float[length];
	array[0] = prev;
	count = fabs(prev - x) < EPSILON ? 0 : -1;

	for (int i = 1; i < length; i++)
	{
		fin >> array[i];
		if (fabs(array[i] - x) < EPSILON)
		{
			right = i;
			count++;
			if (fabs(prev - x) > EPSILON)
				sum += prev;

			if (i == length - 1)
				goto EndCase;
		}
		else
		{
			if (fabs(prev - x) < EPSILON)
			{
				sum += array[i];
			EndCase:
				for (int j = right - count; j <= right; j++)
					array[j] = sum / 2.;
				count = -1;
				sum = 0.;
			}
		}
		prev = array[i];
	}

	for (int i = 0; i < length; i++)
		fout << array[i] << " ";

	delete[] array;

	fin.close();
	fout.close();
}

int main()
{
	Segments();
}
