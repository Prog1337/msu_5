#include <iostream>
#include <fstream>

typedef unsigned int uint;

void Subsets()
{
    std::ifstream fin("input.txt");
    std::ofstream fout("output.txt");
    
    uint N, combinationsCount = 1;
    
    if(!fin || !(fin >> N))
    {
		fout << "0"	<< std::endl;
		fin.close();
		fout.close();
		return;
	}
	
	fout << std::endl;
	combinationsCount <<= N;
	
	for(uint i = 0; i < combinationsCount; i++)
	{
		for(uint j = N; j > 0; j--)
		{
			if((1 << (j - 1)) & i)
				fout << j;
			else
				fout << 0;
		}
		fout << std::endl;
	}
    
}

int main()
{
    Subsets();
}

