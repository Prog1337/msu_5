#include "headers.hpp"
#include <fstream>

int main()
{
    std::ofstream fout;
    int k;
    List<int> *list = Instantiate<int>(k, fout);
    list->Print(fout);
    list->Shift(k);
    list->Print(fout);
}