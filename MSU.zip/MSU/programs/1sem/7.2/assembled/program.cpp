#include <iostream>
#include <fstream>

template <typename T>
class Node
{
public:
    explicit Node(T data, Node<T> *next = nullptr, Node<T> *prev = nullptr)
    {
        _data = data;
        _next = next;
        _prev = prev;
    };

    T Data() { return _data; }

    Node<T> *Next() { return _next; }
    void Next(Node<T> *next) { _next = next; }

    Node<T> *Prev() { return _prev; }
    void Prev(Node<T> *prev) { _prev = prev; }

    ~Node()
    {
        delete _next;
        delete _prev;
    }

private:
    Node<T> *_next;
    Node<T> *_prev;
    T _data;
};

template <typename T>
class List
{
public:
    explicit List()
    {
        _size = 0;
        _head = _tail = nullptr;
    }

    void PushFront(T data)
    {
        Node<T> *newNode = new Node<T>(data);

        if (_size == 0)
            _head = _tail = newNode;
        else
        {
            _head->Prev(newNode);
            newNode->Next(_head);
            _head = newNode;
        }
        _size++;
    }

    void PushTail(T data)
    {
        Node<T> *newNode = new Node<T>(data);

        if (_size == 0)
            _head = _tail = newNode;
        else
        {
            _tail->Next(newNode);
            newNode->Prev(_tail);
            _tail = newNode;
        }
        _size++;
    }

    void Shift(const int k)
    {
        if (k % _size == 0)
            return;

        _head->Prev(_tail);
        _tail->Next(_head);

        if (k > 0)
            for (int i = 0; i < k; i++)
            {
                _head = _head->Next();
                _tail = _tail->Next();
            }
        else
            for (int i = 0; i < 0 - k; i++)
            {
                _head = _head->Prev();
                _tail = _tail->Prev();
            }

        _tail->Next(nullptr);
        _head->Prev(nullptr);
    }

    void Print(std::ofstream &fout)
    {
        Node<T> *temp = _head;
        for (int i = 0; i < _size; i++)
        {
            fout << temp->Data() << " ";
            if (temp == _tail)
                break;
            temp = temp->Next();
        }
        fout << std::endl;
    }

    int Size() { return _size; }

    bool IsEmpty() { return _size == 0; }

    ~List()
    {
        delete _head;
        delete _tail;
    }

private:
    Node<T> *_head;
    Node<T> *_tail;
    int _size;
};

template <typename T>
List<T> *Instantiate(int &k, std::ifstream &fin, std::ofstream &fout)
{
    T data;
    int N, newN = 0;

    if (!fin || !(fin >> N) || N <= 0)
        return nullptr;

    fin >> k;

    List<T> *list = new List<T>();
    for (int i = 0; i < N; i++)
    {
        if (fin >> data)
        {
            list->PushTail(data);
            newN++;
        }
        else
        {
            N = newN;
            if (N == 0)
                return nullptr;
            break;
        }
    }

    return list;
}

int main()
{
    std::ifstream fin("input.txt");
    std::ofstream fout("output.txt");
    int k;
    List<double> *list = Instantiate<double>(k, fin, fout);
    if (list == nullptr)
    {
        fout << "0" << std::endl;
        return 0;
    }
    list->Shift(k);
    list->Print(fout);

    fin.close();
    fout.close();
}
