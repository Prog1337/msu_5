#pragma once

#include "list.hpp"
#include "listInstantiation.hpp"
#include "node.hpp"
#include "shift.hpp"