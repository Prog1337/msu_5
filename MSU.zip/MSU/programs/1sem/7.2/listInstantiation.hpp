#pragma once

#include "list.hpp"

#include <fstream>

template <typename T>
List<T> *Instantiate(const int& k, std::ofstream& fileOutput)
{
    std::ifstream fin("input.txt");
    std::ofstream fout("output.txt");

    fileOutput = fout;

    T data;
    int n;

    if (!fin || !(fin >> n) || n <= 0)
    {
        fout << "0" << std::endl;
        fin.close();
        fout.close();
        return nullptr;
    }

    fin >> k;

    List<T> *list = new List<T>(n);
    for (int i = 0; i < n; i++)
    {
        fin >> data;
        list->PushFront(data);
    }

    fin.close();
    fout.close();

    return list;
}