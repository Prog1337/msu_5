#pragma once

template <typename T>
class Node
{
public:
    explicit Node(T data, Node<T> *next = nullptr, Node<T> *prev = nullptr)
    {
        _data = data;
        _next = next;
        _prev = prev;
    };

    T Data() { return _data; }

    Node<T> *Next() { return _next; }
    void Next(Node<T> *next) { _next = next; }

    Node<T> *Prev() { return _prev; }
    void Prev(Node<T> *prev) { _prev = prev; }

    ~Node()
    {
        delete _next;
        delete _prev;
    }

private:
    Node<T> *_next;
    Node<T> *_prev;
    T _data;
};