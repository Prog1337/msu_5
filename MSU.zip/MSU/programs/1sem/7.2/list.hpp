#pragma once

#include <fstream>
#include "node.hpp"

template <typename T>
class List
{
public:
    explicit List(int size)
    {
        _currentSize = 0;
        _size = size;
        _head = _tail = nullptr;
    }

    void PushFront(T data)
    {
        if (IsFull())
            return;

        Node<T> *newNode = new Node<T>(data);

        if (_currentSize == 0)
            _head = _tail = newNode;
        else
        {
            _head->Prev(newNode);
            newNode->Next(_head);
            _head = newNode;
        }
        _currentSize++;
    }

    void PushTail(T data)
    {
        if (IsFull())
            return;

        Node<T> *newNode = new Node<T>(data, _head, nullptr);

        if (_currentSize == 0)
            _head = _tail = newNode;
        else
        {
            _tail->Next(newNode);
            newNode->Prev(_tail);
            _tail = newNode;
        }
        _currentSize++;
    }

    void Shift(const int k)
    {
        Node<T> *temp = _head;
        for (int i = 0; i < k; i++)
        {
            if (temp->Next())
                _head = temp->Next();
            temp->Prev(_tail);
            _tail->Next(temp);
            _tail = temp;
            _tail->Next(nullptr);
            temp = _head;
        }
    }

    void Print(std::ofstream &fout)
    {
        Node<T> *temp = _tail;
        for (int i = 0; i < _currentSize; i++)
        {
            fout << temp->Data() << " ";
            if (temp == _head)
                break;
            temp = temp->Prev();
        }
        fout << std::endl;
    }

    bool IsEmpty() { return _currentSize == 0; }

    bool IsFull() { return _size == _currentSize; }

    ~List()
    {
        delete _head;
        delete _tail;
    }

private:
    Node<T> *_head;
    Node<T> *_tail;
    int _size, _currentSize;
};