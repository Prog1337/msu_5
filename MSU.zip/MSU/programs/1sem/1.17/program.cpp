#include <iostream>
#include <fstream>

void MaxLength()
{
	std::ifstream fin("input.txt");
	std::ofstream fout("output.txt");
	int length = 0, maxLength = 0, prev, cur;
	fin >> cur;
	prev = cur;
	while (!fin.eof())
	{
		fin >> cur;
		length++;
		if (cur != prev)
		{
			if (maxLength < length)
				maxLength = length;
			length = 0;
		}
		prev = cur;
	}
	fout << maxLength;
	fin.close();
	fout.close();
}

int main()
{
	MaxLength();
}
