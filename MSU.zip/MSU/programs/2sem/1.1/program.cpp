#include <iostream>
#include <fstream>
#include <cmath>

bool IsMonotonic(const char *y, int left, int right)
{
    int count = right - left + 1;
    if (count <= 2)
    {
        if (count == 2 && y[left] == '1' && y[right] == '0')
            return false;
        return true;
    }
    int pivot = count / 2;

    for (int i = 0, j = pivot; i < pivot; i++, j++)
    {
        if (y[i] == '1' && y[j] == '0')
            return false;
    }

    if (IsMonotonic(y, left, left + pivot - 1) == false)
        return false;
    if (IsMonotonic(y, left + pivot, right) == false)
        return false;

    return true;
}

bool IsMonotonic(std::ifstream &fin, std::ofstream &fout)
{
    int k, n, count;
    char *y;

    if (!(fin >> k) || k != 2 || !(fin >> n) || n <= 0)
        return false;

    count = pow(k, n);
    y = new char[count];

    if (!(fin >> y))
        return false;

    return IsMonotonic(y, 0, count - 1);
}

int main(int argc, char *argv[])
{
    std::ifstream fin(argv[1]);
    std::ofstream fout(argv[2]);

    fout << (IsMonotonic(fin, fout) ? 1 : 0) << std::endl;

    fin.close();
    fout.close();
}
